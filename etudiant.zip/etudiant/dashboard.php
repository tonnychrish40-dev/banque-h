<?php
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';
requireRole('etudiant');

$user_id = $_SESSION['user_id'];

// Récupérer les infos de l'utilisateur
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Vérifier si le profil existe
$stmt = $pdo->prepare("SELECT p.*, f.nom as filiere_nom FROM profils_etudiants p LEFT JOIN filieres f ON p.filiere_id = f.id WHERE p.etudiant_id = ?");
$stmt->execute([$user_id]);
$profil = $stmt->fetch();

$profil_complet = false;
$filiere_ok = false;
if ($profil && !empty($profil['filiere_id']) && !empty($profil['niveau_etude'])) {
    $filiere_ok = true;
    if (!empty($profil['matricule'])) {
        $profil_complet = true;
    }
}

// Progression questionnaire
$nb_reponses = 0;
$total_questions = 0;
$questionnaire_fait = false;
if ($filiere_ok) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM reponses_etudiants WHERE etudiant_id = ?");
    $stmt->execute([$user_id]);
    $nb_reponses = $stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM questionnaires");
    $stmt->execute();
    $total_questions = $stmt->fetchColumn();
    if ($total_questions > 0 && $nb_reponses >= $total_questions) {
        $questionnaire_fait = true;
    }
}

// Score global
$score_global = 0;
$bonnes = 0;
if ($nb_reponses > 0) {
    $stmt = $pdo->prepare("
        SELECT SUM(CASE WHEN r.reponse = q.bonne_reponse THEN 1 ELSE 0 END) as bonnes
        FROM reponses_etudiants r
        JOIN questionnaires q ON r.question_id = q.id
        WHERE r.etudiant_id = ?
    ");
    $stmt->execute([$user_id]);
    $bonnes = $stmt->fetchColumn();
    $score_global = round(($bonnes / $nb_reponses) * 100);
}

// Compter les messages non lus
$stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE destinataire_id = ? AND lu = 0");
$stmt->execute([$user_id]);
$messages_non_lus = $stmt->fetchColumn();

// Compter les offres disponibles - sans utiliser la colonne status
$nb_offres = 0;
try {
    // Vérifier d'abord si la table offres existe
    $stmt = $pdo->query("SHOW TABLES LIKE 'offres'");
    if ($stmt->rowCount() > 0) {
        // La table existe, compter toutes les offres
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM offres");
        $stmt->execute();
        $nb_offres = $stmt->fetchColumn();
    }
} catch (PDOException $e) {
    $nb_offres = 0;
}

require_once dirname(__DIR__) . '/includes/header.php';
?>

<style>
/* Dashboard Header */
.dashboard-header {
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 1rem;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    color: white;
}
.dashboard-header h1 {
    font-size: 1.5rem;
    margin-bottom: 0.3rem;
}
.dashboard-header p {
    opacity: 0.9;
    font-size: 0.85rem;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
}
.stat-card {
    background: white;
    border-radius: 1rem;
    padding: 1rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 1px 3px 0 rgba(0,0,0,0.1);
    border: 1px solid #e5e7eb;
    transition: transform 0.2s;
}
.stat-card:hover {
    transform: translateY(-3px);
}
.stat-icon {
    font-size: 2rem;
    background: #f3f4f6;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 1rem;
}
.stat-info h3 {
    font-size: 0.75rem;
    color: #6b7280;
    margin-bottom: 0.2rem;
}
.stat-value {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1f2937;
}
.stat-info small {
    font-size: 0.7rem;
    color: #9ca3af;
}
.stat-info a {
    font-size: 0.7rem;
    color: #667eea;
    text-decoration: none;
}
.stat-info a:hover {
    text-decoration: underline;
}

/* Alertes */
.alerts-container {
    margin-bottom: 1.5rem;
}
.alert {
    padding: 1rem;
    border-radius: 0.75rem;
    margin-bottom: 0.8rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 1rem;
}
.alert-warning {
    background: #fed7aa;
    color: #92400e;
    border-left: 4px solid #f59e0b;
}
.alert-info {
    background: #dbeafe;
    color: #1e40af;
    border-left: 4px solid #3b82f6;
}
.alert-success {
    background: #d1fae5;
    color: #065f46;
    border-left: 4px solid #10b981;
}
.alert strong {
    display: block;
    margin-bottom: 0.3rem;
}
.btn-sm {
    padding: 0.3rem 0.8rem;
    font-size: 0.75rem;
    border-radius: 0.5rem;
    text-decoration: none;
    background: rgba(0,0,0,0.1);
    color: inherit;
}
.btn-sm:hover {
    background: rgba(0,0,0,0.2);
}

/* Message non lu */
.message-alert {
    background: linear-gradient(135deg, #fef3c7, #fde68a);
    border-left: 4px solid #f59e0b;
}

/* Actions Grid */
.actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 1rem;
    margin-top: 1rem;
}
.action-card {
    background: white;
    border-radius: 1rem;
    padding: 1rem;
    text-align: center;
    text-decoration: none;
    transition: all 0.2s;
    border: 1px solid #e5e7eb;
    box-shadow: 0 1px 3px 0 rgba(0,0,0,0.05);
    position: relative;
}
.action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
    border-color: #667eea;
}
.action-icon {
    font-size: 2rem;
    margin-bottom: 0.5rem;
}
.action-card h3 {
    font-size: 0.9rem;
    color: #1f2937;
    margin-bottom: 0.2rem;
}
.action-card p {
    font-size: 0.7rem;
    color: #6b7280;
}
.notif-badge {
    position: absolute;
    top: -8px;
    right: -8px;
    background: #ef4444;
    color: white;
    font-size: 0.6rem;
    padding: 2px 6px;
    border-radius: 20px;
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    .actions-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    .alert {
        flex-direction: column;
        text-align: center;
    }
}
</style>

<!-- En-tête avec message de bienvenue personnalisé -->
<div class="dashboard-header">
    <h1>👋 Bonjour, <?= nettoyer($_SESSION['user_prenom'] ?? $_SESSION['user_nom']) ?> !</h1>
    <p>Bienvenue dans votre espace d'orientation personnalisé</p>
</div>

<!-- Messages non lus -->
<?php if ($messages_non_lus > 0): ?>
    <div class="alert message-alert">
        <div>
            <strong>📬 Vous avez <?= $messages_non_lus ?> message(s) non lu(s)</strong>
        </div>
        <a href="messages.php" class="btn-sm">📖 Consulter mes messages</a>
    </div>
<?php endif; ?>

<!-- Cartes de progression générale -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">📊</div>
        <div class="stat-info">
            <h3>Progression questionnaire</h3>
            <div class="stat-value"><?= $total_questions > 0 ? round(($nb_reponses / $total_questions) * 100) : 0 ?>%</div>
            <small><?= $nb_reponses ?> / <?= $total_questions ?> questions</small>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🎓</div>
        <div class="stat-info">
            <h3>Ma filière</h3>
            <div class="stat-value"><?= $profil && $profil['filiere_nom'] ? htmlspecialchars($profil['filiere_nom']) : 'À définir' ?></div>
            <a href="profil.php">Modifier</a>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📈</div>
        <div class="stat-info">
            <h3>Score global</h3>
            <div class="stat-value"><?= $score_global ?>%</div>
            <small><?= $bonnes ?> bonnes réponses</small>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">💼</div>
        <div class="stat-info">
            <h3>Offres disponibles</h3>
            <div class="stat-value"><?= $nb_offres ?></div>
            <a href="offres.php">Voir les offres</a>
        </div>
    </div>
</div>

<!-- ALERTES GUIDÉES -->
<div class="alerts-container">
    <?php if (!$filiere_ok): ?>
        <div class="alert alert-warning">
            <div>
                <strong>⚠️ Étape 1 : Choisissez votre filière</strong><br>
                Sélectionnez votre filière d'étude pour bénéficier d'un questionnaire adapté.
            </div>
            <a href="profil.php" class="btn-sm">🎓 Choisir ma filière</a>
        </div>
    <?php elseif (!$questionnaire_fait): ?>
        <div class="alert alert-info">
            <div>
                <strong>📝 Étape 2 : Évaluez vos compétences</strong><br>
                Le questionnaire vous permettra de mesurer votre niveau et d'obtenir des recommandations de métiers.
            </div>
            <a href="questionnaire.php" class="btn-sm">🚀 Passer le test</a>
        </div>
    <?php else: ?>
        <div class="alert alert-success">
            <div>
                <strong>✅ Félicitations !</strong><br>
                Votre profil est complet. Consultez vos résultats pour découvrir les métiers qui vous correspondent.
            </div>
            <a href="resultats.php" class="btn-sm">🎯 Voir mes résultats</a>
        </div>
    <?php endif; ?>
</div>

<!-- Actions rapides -->
<div class="actions-grid">
    <a href="profil.php" class="action-card">
        <div class="action-icon">👤</div>
        <h3>Mon profil</h3>
        <p>Informations personnelles</p>
    </a>
    <a href="questionnaire.php" class="action-card">
        <div class="action-icon">📝</div>
        <h3>Questionnaire</h3>
        <p>Évaluer mes compétences</p>
    </a>
    <a href="resultats.php" class="action-card">
        <div class="action-icon">🎯</div>
        <h3>Résultats</h3>
        <p>Voir mon score & métiers</p>
    </a>
    <a href="ressources.php" class="action-card">
        <div class="action-icon">📖</div>
        <h3>Ressources</h3>
        <p>Se former</p>
    </a>
    <a href="offres.php" class="action-card">
        <div class="action-icon">💼</div>
        <h3>Offres</h3>
        <p>Emplois & stages</p>
    </a>
    <a href="messages.php" class="action-card">
        <div class="action-icon">💬</div>
        <h3>Messages</h3>
        <p>Contacter mon conseiller</p>
        <?php if ($messages_non_lus > 0): ?>
            <span class="notif-badge"><?= $messages_non_lus ?></span>
        <?php endif; ?>
    </a>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>