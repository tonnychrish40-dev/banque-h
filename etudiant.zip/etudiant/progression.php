<?php
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';
requireRole('etudiant');

$user_id = $_SESSION['user_id'];
$onglet = $_GET['onglet'] ?? 'experiences';
$erreur = '';
$succes = '';

// ---------- GESTION DES EXPÉRIENCES ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ajouter_experience'])) {
    $titre = nettoyer($_POST['titre']);
    $entreprise = nettoyer($_POST['entreprise']);
    $type = $_POST['type'];
    $debut = $_POST['date_debut'] ?: null;
    $fin = $_POST['date_fin'] ?: null;
    $desc = nettoyer($_POST['description']);
    if (empty($titre)) $erreur = "Le titre de l'expérience est requis.";
    else {
        $stmt = $pdo->prepare("INSERT INTO experiences (etudiant_id, titre, entreprise, type, date_debut, date_fin, description) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$user_id, $titre, $entreprise, $type, $debut, $fin, $desc]);
        header("Location: progression.php?onglet=experiences&success=1");
        exit;
    }
}
if (isset($_GET['supprimer_exp'])) {
    $id = (int)$_GET['supprimer_exp'];
    $stmt = $pdo->prepare("DELETE FROM experiences WHERE id = ? AND etudiant_id = ?");
    $stmt->execute([$id, $user_id]);
    header("Location: progression.php?onglet=experiences");
    exit;
}

// ---------- GESTION DES CERTIFICATIONS ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ajouter_certification'])) {
    $nom = nettoyer($_POST['nom_certif']);
    $organisme = nettoyer($_POST['organisme']);
    $date_obt = $_POST['date_obtention'] ?: null;
    $lien = nettoyer($_POST['lien_justificatif']);
    if (empty($nom)) $erreur = "Le nom de la certification est requis.";
    else {
        $stmt = $pdo->prepare("INSERT INTO certifications (etudiant_id, nom, organisme, date_obtention, lien_justificatif) VALUES (?,?,?,?,?)");
        $stmt->execute([$user_id, $nom, $organisme, $date_obt, $lien]);
        header("Location: progression.php?onglet=certifications&success=1");
        exit;
    }
}
if (isset($_GET['supprimer_cert'])) {
    $id = (int)$_GET['supprimer_cert'];
    $stmt = $pdo->prepare("DELETE FROM certifications WHERE id = ? AND etudiant_id = ?");
    $stmt->execute([$id, $user_id]);
    header("Location: progression.php?onglet=certifications");
    exit;
}

// ---------- GESTION DES RÉALISATIONS ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ajouter_realisation'])) {
    $titre = nettoyer($_POST['titre_real']);
    $description = nettoyer($_POST['description_real']);
    $date_real = $_POST['date_realisation'] ?: null;
    $lien = nettoyer($_POST['lien_real']);
    if (empty($titre)) $erreur = "Le titre de la réalisation est requis.";
    else {
        $stmt = $pdo->prepare("INSERT INTO realisations (etudiant_id, titre, description, date_realisation, lien) VALUES (?,?,?,?,?)");
        $stmt->execute([$user_id, $titre, $description, $date_real, $lien]);
        header("Location: progression.php?onglet=realisations&success=1");
        exit;
    }
}
if (isset($_GET['supprimer_real'])) {
    $id = (int)$_GET['supprimer_real'];
    $stmt = $pdo->prepare("DELETE FROM realisations WHERE id = ? AND etudiant_id = ?");
    $stmt->execute([$id, $user_id]);
    header("Location: progression.php?onglet=realisations");
    exit;
}

// ---------- GESTION DES OBJECTIFS ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ajouter_objectif'])) {
    $metier = nettoyer($_POST['metier_cible']);
    $description = nettoyer($_POST['description_objectif']);
    if (empty($metier)) $erreur = "Le métier cible est requis.";
    else {
        $stmt = $pdo->prepare("SELECT id FROM objectifs_carriere WHERE etudiant_id = ? AND statut = 'en_cours'");
        $stmt->execute([$user_id]);
        $existant = $stmt->fetch();
        if ($existant) {
            $stmt = $pdo->prepare("UPDATE objectifs_carriere SET metier_cible = ?, description_objectif = ? WHERE id = ?");
            $stmt->execute([$metier, $description, $existant['id']]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO objectifs_carriere (etudiant_id, metier_cible, description_objectif) VALUES (?,?,?)");
            $stmt->execute([$user_id, $metier, $description]);
        }
        header("Location: progression.php?onglet=objectifs&success=1");
        exit;
    }
}
if (isset($_GET['changer_statut'])) {
    $id = (int)$_GET['changer_statut'];
    $statut = $_GET['statut'];
    $stmt = $pdo->prepare("UPDATE objectifs_carriere SET statut = ? WHERE id = ? AND etudiant_id = ?");
    $stmt->execute([$statut, $id, $user_id]);
    header("Location: progression.php?onglet=objectifs");
    exit;
}

// Récupération des données
$experiences = $pdo->prepare("SELECT * FROM experiences WHERE etudiant_id = ? ORDER BY date_debut DESC");
$experiences->execute([$user_id]);
$experiences = $experiences->fetchAll();

$certifications = $pdo->prepare("SELECT * FROM certifications WHERE etudiant_id = ? ORDER BY date_obtention DESC");
$certifications->execute([$user_id]);
$certifications = $certifications->fetchAll();

$realisations = $pdo->prepare("SELECT * FROM realisations WHERE etudiant_id = ? ORDER BY date_realisation DESC");
$realisations->execute([$user_id]);
$realisations = $realisations->fetchAll();

$objectifs = $pdo->prepare("SELECT * FROM objectifs_carriere WHERE etudiant_id = ? ORDER BY date_creation DESC");
$objectifs->execute([$user_id]);
$objectifs = $objectifs->fetchAll();

require_once dirname(__DIR__) . '/includes/header.php';
?>

<style>
/* Header de la page */
.page-header {
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 1rem;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    color: white;
}
.page-header h1 {
    font-size: 1.5rem;
    margin-bottom: 0.3rem;
}
.page-header p {
    opacity: 0.9;
    font-size: 0.85rem;
}

/* Alertes */
.alert {
    padding: 1rem;
    border-radius: 0.75rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.alert-success {
    background: #d1fae5;
    color: #065f46;
    border-left: 4px solid #10b981;
}
.alert-error {
    background: #fee2e2;
    color: #991b1b;
    border-left: 4px solid #ef4444;
}
.alert-info {
    background: #dbeafe;
    color: #1e40af;
    border-left: 4px solid #3b82f6;
}

/* Onglets */
.tabs {
    display: flex;
    gap: 0.5rem;
    border-bottom: 2px solid #e5e7eb;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
}
.tab-btn {
    padding: 0.7rem 1.2rem;
    text-decoration: none;
    color: #6b7280;
    font-weight: 500;
    border-radius: 0.5rem 0.5rem 0 0;
    transition: all 0.2s;
}
.tab-btn:hover {
    background: #f3f4f6;
    color: #1f2937;
}
.tab-btn.active {
    color: #667eea;
    border-bottom: 2px solid #667eea;
    background: #f5f3ff;
}

/* Cartes de formulaire */
.form-card {
    background: white;
    border-radius: 1rem;
    padding: 1.2rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 1px 3px 0 rgba(0,0,0,0.1);
    border: 1px solid #e5e7eb;
}
.form-card h3 {
    font-size: 1rem;
    margin-bottom: 1rem;
    color: #1f2937;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.form-row {
    display: flex;
    gap: 0.8rem;
    margin-bottom: 0.8rem;
    flex-wrap: wrap;
}
.form-row input, .form-row select {
    flex: 1;
    min-width: 120px;
}
input, select, textarea {
    width: 100%;
    padding: 0.6rem;
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    font-size: 0.85rem;
    font-family: inherit;
    transition: all 0.2s;
}
input:focus, select:focus, textarea:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
}
.btn-primary {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 0.5rem;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.2s;
}
.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102,126,234,0.4);
}
.btn-sm {
    display: inline-block;
    padding: 0.3rem 0.8rem;
    font-size: 0.75rem;
    border-radius: 0.5rem;
    text-decoration: none;
    background: #f3f4f6;
    color: #4b5563;
    margin-right: 0.5rem;
    transition: all 0.2s;
}
.btn-sm:hover {
    background: #e5e7eb;
}
.btn-danger {
    color: #ef4444;
    background: #fee2e2;
}
.btn-danger:hover {
    background: #fecaca;
}

/* Tableaux */
.data-table {
    width: 100%;
    background: white;
    border-radius: 1rem;
    overflow: hidden;
    box-shadow: 0 1px 3px 0 rgba(0,0,0,0.1);
    border: 1px solid #e5e7eb;
}
.data-table thead {
    background: #f9fafb;
}
.data-table th {
    padding: 0.8rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.8rem;
    color: #4b5563;
    border-bottom: 1px solid #e5e7eb;
}
.data-table td {
    padding: 0.8rem;
    font-size: 0.8rem;
    border-bottom: 1px solid #e5e7eb;
    color: #1f2937;
}
.data-table tr:last-child td {
    border-bottom: none;
}
.data-table tr:hover {
    background: #f9fafb;
}
.data-table a {
    text-decoration: none;
    font-size: 1.1rem;
}

/* Objectif item */
.objectif-item {
    background: white;
    border-radius: 1rem;
    padding: 1.2rem;
    margin-bottom: 1rem;
    box-shadow: 0 1px 3px 0 rgba(0,0,0,0.1);
    border: 1px solid #e5e7eb;
    transition: all 0.2s;
}
.objectif-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.objectif-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 0.5rem;
}
.objectif-title {
    font-size: 1.1rem;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
}
.badge {
    padding: 0.2rem 0.8rem;
    border-radius: 2rem;
    font-size: 0.7rem;
    font-weight: 600;
}
.badge-en_cours {
    background: #fef3c7;
    color: #92400e;
}
.badge-atteint {
    background: #d1fae5;
    color: #065f46;
}
.badge-abandonne {
    background: #fee2e2;
    color: #991b1b;
}
.objectif-description {
    color: #4b5563;
    font-size: 0.85rem;
    margin: 0.5rem 0;
    line-height: 1.5;
}
.objectif-date {
    font-size: 0.7rem;
    color: #9ca3af;
}
.objectif-actions {
    margin-top: 0.8rem;
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
}

/* Responsive */
@media (max-width: 768px) {
    .form-row {
        flex-direction: column;
        gap: 0.5rem;
    }
    .form-row input, .form-row select {
        width: 100%;
    }
    .data-table {
        display: block;
        overflow-x: auto;
    }
    .objectif-header {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>

<div class="page-header">
    <h1>📈 Ma progression professionnelle</h1>
    <p>Gérez vos expériences, certifications, réalisations et objectif de carrière</p>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success">✅ Opération réussie !</div>
<?php endif; ?>
<?php if ($erreur): ?>
    <div class="alert alert-error">❌ <?= htmlspecialchars($erreur) ?></div>
<?php endif; ?>

<!-- Onglets -->
<div class="tabs">
    <a href="?onglet=experiences" class="tab-btn <?= $onglet == 'experiences' ? 'active' : '' ?>">💼 Expériences</a>
    <a href="?onglet=certifications" class="tab-btn <?= $onglet == 'certifications' ? 'active' : '' ?>">🎓 Certifications</a>
    <a href="?onglet=realisations" class="tab-btn <?= $onglet == 'realisations' ? 'active' : '' ?>">🏆 Réalisations</a>
    <a href="?onglet=objectifs" class="tab-btn <?= $onglet == 'objectifs' ? 'active' : '' ?>">🎯 Objectif carrière</a>
</div>

<!-- Expériences -->
<div id="experiences" style="display: <?= $onglet == 'experiences' ? 'block' : 'none' ?>;">
    <div class="form-card">
        <h3>➕ Ajouter une expérience</h3>
        <form method="POST">
            <div class="form-row">
                <input type="text" name="titre" placeholder="Titre du poste *" required>
                <input type="text" name="entreprise" placeholder="Entreprise / Organisation">
                <select name="type">
                    <option value="stage">🎯 Stage</option>
                    <option value="emploi">💼 Emploi</option>
                    <option value="benevolat">🤝 Bénévolat</option>
                    <option value="autre">📌 Autre</option>
                </select>
            </div>
            <div class="form-row">
                <input type="date" name="date_debut" placeholder="Date de début">
                <span>→</span>
                <input type="date" name="date_fin" placeholder="Date de fin">
            </div>
            <textarea name="description" rows="2" placeholder="Description de l'expérience (optionnel)"></textarea>
            <button type="submit" name="ajouter_experience" class="btn-primary">📌 Ajouter l'expérience</button>
        </form>
    </div>
    
    <?php if (empty($experiences)): ?>
        <div class="alert alert-info">📭 Aucune expérience enregistrée. Ajoutez votre première expérience ci-dessus !</div>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr><th>Titre</th><th>Entreprise</th><th>Type</th><th>Période</th><th style="width:50px">Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($experiences as $e): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($e['titre']) ?></strong></td>
                    <td><?= htmlspecialchars($e['entreprise']) ?></td>
                    <td><?= $e['type'] ?></td>
                    <td><?= $e['date_debut'] ? date('d/m/Y', strtotime($e['date_debut'])) : '?' ?> - <?= $e['date_fin'] ? date('d/m/Y', strtotime($e['date_fin'])) : 'Présent' ?></td>
                    <td><a href="?supprimer_exp=<?= $e['id'] ?>&onglet=experiences" onclick="return confirm('Supprimer cette expérience ?')" style="color:#ef4444;">🗑️</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Certifications -->
<div id="certifications" style="display: <?= $onglet == 'certifications' ? 'block' : 'none' ?>;">
    <div class="form-card">
        <h3>➕ Ajouter une certification</h3>
        <form method="POST">
            <input type="text" name="nom_certif" placeholder="Nom de la certification *" required>
            <input type="text" name="organisme" placeholder="Organisme délivreur" style="margin-top:0.5rem;">
            <input type="date" name="date_obtention" placeholder="Date d'obtention" style="margin-top:0.5rem;">
            <input type="url" name="lien_justificatif" placeholder="Lien vers le justificatif (optionnel)" style="margin-top:0.5rem;">
            <button type="submit" name="ajouter_certification" class="btn-primary" style="margin-top:0.8rem;">🎓 Ajouter la certification</button>
        </form>
    </div>
    
    <?php if (empty($certifications)): ?>
        <div class="alert alert-info">📭 Aucune certification enregistrée.</div>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr><th>Nom</th><th>Organisme</th><th>Date d'obtention</th><th style="width:50px">Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($certifications as $c): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($c['nom']) ?></strong></td>
                    <td><?= htmlspecialchars($c['organisme']) ?></td>
                    <td><?= $c['date_obtention'] ? date('d/m/Y', strtotime($c['date_obtention'])) : '-' ?></td>
                    <td><a href="?supprimer_cert=<?= $c['id'] ?>&onglet=certifications" onclick="return confirm('Supprimer cette certification ?')" style="color:#ef4444;">🗑️</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Réalisations -->
<div id="realisations" style="display: <?= $onglet == 'realisations' ? 'block' : 'none' ?>;">
    <div class="form-card">
        <h3>➕ Ajouter une réalisation</h3>
        <form method="POST">
            <input type="text" name="titre_real" placeholder="Titre de la réalisation *" required>
            <textarea name="description_real" rows="2" placeholder="Description de la réalisation" style="margin-top:0.5rem;"></textarea>
            <input type="date" name="date_realisation" placeholder="Date" style="margin-top:0.5rem;">
            <input type="url" name="lien_real" placeholder="Lien (projet, portfolio, etc.)" style="margin-top:0.5rem;">
            <button type="submit" name="ajouter_realisation" class="btn-primary" style="margin-top:0.8rem;">🏆 Ajouter la réalisation</button>
        </form>
    </div>
    
    <?php if (empty($realisations)): ?>
        <div class="alert alert-info">📭 Aucune réalisation enregistrée.</div>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr><th>Titre</th><th>Description</th><th>Date</th><th style="width:50px">Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($realisations as $r): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($r['titre']) ?></strong></td>
                    <td><?= htmlspecialchars(substr($r['description'], 0, 60)) . (strlen($r['description']) > 60 ? '...' : '') ?></td>
                    <td><?= $r['date_realisation'] ? date('d/m/Y', strtotime($r['date_realisation'])) : '-' ?></td>
                    <td><a href="?supprimer_real=<?= $r['id'] ?>&onglet=realisations" onclick="return confirm('Supprimer cette réalisation ?')" style="color:#ef4444;">🗑️</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Objectif carrière -->
<div id="objectifs" style="display: <?= $onglet == 'objectifs' ? 'block' : 'none' ?>;">
    <div class="form-card">
        <h3>🎯 Définir mon objectif de carrière</h3>
        <form method="POST">
            <input type="text" name="metier_cible" placeholder="Métier visé (ex: Data Scientist, Développeur Web)" required>
            <textarea name="description_objectif" rows="3" placeholder="Description de votre objectif, étapes à franchir..." style="margin-top:0.5rem;"></textarea>
            <button type="submit" name="ajouter_objectif" class="btn-primary" style="margin-top:0.8rem;">🎯 Enregistrer mon objectif</button>
        </form>
    </div>
    
    <?php if (empty($objectifs)): ?>
        <div class="alert alert-info">📭 Aucun objectif défini. Créez-en un ci-dessus !</div>
    <?php else: ?>
        <?php foreach ($objectifs as $o): ?>
            <div class="objectif-item">
                <div class="objectif-header">
                    <h3 class="objectif-title">🎯 <?= htmlspecialchars($o['metier_cible']) ?></h3>
                    <span class="badge badge-<?= $o['statut'] ?>">
                        <?= $o['statut'] == 'en_cours' ? '🟢 En cours' : ($o['statut'] == 'atteint' ? '✅ Atteint' : '⛔ Abandonné') ?>
                    </span>
                </div>
                <div class="objectif-description">
                    <?= nl2br(htmlspecialchars($o['description_objectif'])) ?>
                </div>
                <div class="objectif-date">
                    📅 Créé le <?= date('d/m/Y', strtotime($o['date_creation'])) ?>
                </div>
                <div class="objectif-actions">
                    <a href="?changer_statut=<?= $o['id'] ?>&statut=en_cours&onglet=objectifs" class="btn-sm">🟢 En cours</a>
                    <a href="?changer_statut=<?= $o['id'] ?>&statut=atteint&onglet=objectifs" class="btn-sm">✅ Atteint</a>
                    <a href="?changer_statut=<?= $o['id'] ?>&statut=abandonne&onglet=objectifs" class="btn-sm btn-danger">⛔ Abandonné</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>